/*
 UIPEthernet.h - Arduino implementation of a uIP wrapper class.
 Copyright (c) 2013 Norbert Truchsess <norbert.truchsess@t-online.de>
 All rights reserved.

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
  */

#ifndef UIPETHERNET_H
#define UIPETHERNET_H

#include "ethernet_comp.h"
#include <Arduino.h>
#include "Dhcp.h"
#include "IPAddress.h"
#include "utility/Enc28J60Network.h"
#include "UIPClient.h"
#include "UIPServer.h"
#include "UIPUdp.h"

extern "C"
{
#include "utility/uip_timer.h"
#include "utility/uip.h"
}

//#define UIPETHERNET_DEBUG
//#define UIPETHERNET_DEBUG_CHKSUM
//#define UIPETHERNET_DEBUG_UDP
//#define UIPETHERNET_DEBUG_CLIENT

#define UIPETHERNET_FREEPACKET 1
#define UIPETHERNET_SENDPACKET 2
#define UIPETHERNET_BUFFERREAD 4

#define uip_ip_addr(addr, ip) do { \
                     ((u16_t *)(addr))[0] = HTONS(((ip[0]) << 8) | (ip[1])); \
                     ((u16_t *)(addr))[1] = HTONS(((ip[2]) << 8) | (ip[3])); \
                  } while(0)

#define ip_addr_uip(a) IPAddress(a[0] & 0xFF, a[0] >> 8 , a[1] & 0xFF, a[1] >> 8); //TODO this is not IPV6 capable

#define uip_seteth_addr(eaddr) do {uip_ethaddr.addr[0] = eaddr[0]; \
                              uip_ethaddr.addr[1] = eaddr[1];\
                              uip_ethaddr.addr[2] = eaddr[2];\
                              uip_ethaddr.addr[3] = eaddr[3];\
                              uip_ethaddr.addr[4] = eaddr[4];\
                              uip_ethaddr.addr[5] = eaddr[5];} while(0)

typedef void
(*fn_uip_cb_t)(uip_tcp_appstate_t *conn);

typedef void
(*fn_uip_udp_cb_t)(uip_udp_appstate_t *conn);

#define BUF ((struct uip_tcpip_hdr *)&uip_buf[UIP_LLH_LEN])

class UIPEthernetClass
{
public:
  UIPEthernetClass();

  int begin(const uint8_t* mac);
  void begin(const uint8_t* mac, IPAddress ip);
  void begin(const uint8_t* mac, IPAddress ip, IPAddress dns);
  void begin(const uint8_t* mac, IPAddress ip, IPAddress dns, IPAddress gateway);
  void begin(const uint8_t* mac, IPAddress ip, IPAddress dns, IPAddress gateway, IPAddress subnet);

  // maintain() must be called at regular intervals to process the incoming serial
  // data and issue IP events to the sketch.  It does not return until all IP
  // events have been processed. Renews dhcp-lease if required.
  int maintain();

  IPAddress localIP();
  IPAddress subnetMask();
  IPAddress gatewayIP();
  IPAddress dnsServerIP();

  // Set a user function to handle raw uIP events as they happen.  The
  // callback function can only use uIP functions, but it can also use uIP's
  // protosockets.
  void set_uip_callback(fn_uip_cb_t fn);
  void set_uip_udp_callback(fn_uip_udp_cb_t fn);

private:
  IPAddress _dnsServerAddress;
  DhcpClass* _dhcp;

  struct uip_timer periodic_timer;
  fn_uip_cb_t fn_uip_cb;
  fn_uip_udp_cb_t fn_uip_udp_cb;

  memhandle in_packet;
  memhandle uip_packet;
  uint8_t uip_hdrlen;
  uint8_t packetstate;

  Enc28J60Network network;

  void init(const uint8_t* mac);
  void configure(IPAddress ip, IPAddress dns, IPAddress gateway, IPAddress subnet);

  void tick();

  boolean network_send();

  void uip_callback();

  friend void uipethernet_appcall(void);

  void uip_udp_callback();

  friend void uipudp_appcall(void);

  friend class UIPServer;

  friend class UIPClient;

  friend class UIPUDP;

  static uint16_t chksum(uint16_t sum, const uint8_t* data, uint16_t len);
  static uint16_t ipchksum(void);
  uint16_t upper_layer_chksum(uint8_t proto);

  friend uint16_t uip_ipchksum(void);
  friend uint16_t uip_tcpchksum(void);
  friend uint16_t uip_udpchksum(void);

#if UIP_CONF_IPV6
  uint16_t uip_icmp6chksum(void);
#endif /* UIP_CONF_IPV6 */
};

extern UIPEthernetClass UIPEthernet;

#endif
